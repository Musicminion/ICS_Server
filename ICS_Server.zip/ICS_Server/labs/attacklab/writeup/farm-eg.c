/* $begin farm-eg-c */
void setval_210(unsigned *p)
{
    *p = 3347663060U;
}
/* $end farm-eg-c */
